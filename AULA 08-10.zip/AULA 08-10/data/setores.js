[
  {
    "id": 14,
    "nome": "Produção",
    "descricao": "Setor Produção"
  },
  {
    "id": 2,
    "nome": "Engenharia",
    "descricao": "Setor Engenharia"
  }
]
